"""Review probes for tutorials/DIMER_MultiModel_Image_Segmentation_Workshop.ipynb (prefix SEG).

Usage:
    python run_probes.py <notebook.ipynb> [--prepared DIR] [--out results.json]

* Extracts the notebook's carried files (CARRIED_FILES) into a temporary directory and imports the carried
  runner ``workshop.py`` from there, so every probe exercises the notebook's own code, not the repository.
* ``--prepared DIR`` is a directory in which the carried runner's ``prepare`` stage has already run on the
  real pinned FoodSeg103 rows (``python workshop.py --root DIR --stage prepare`` after materialising the
  carried files into DIR). P01 needs it for the real activity boxes; without it P01 reports "not run".
* CPU only. No model weights are loaded: the SAM 2 stage is executed with a stand-in pipeline that returns
  fixed masks, so P01 checks what the stage *records and displays*, not SAM 2's behaviour.

Each probe reports ``open`` (the reviewed defect is present) or ``clear``, plus its evidence basis.
"""

from __future__ import annotations

import argparse
import ast
import contextlib
import hashlib
import io
import json
import re
import sys
import tempfile
import types
from pathlib import Path

import numpy as np
from PIL import Image


def load_notebook(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def cells_by_id(nb: dict) -> dict:
    return {c["id"]: "".join(c["source"]) for c in nb["cells"]}


def carried_files(nb: dict) -> dict:
    for cell in nb["cells"]:
        src = "".join(cell["source"])
        if src.startswith("CARRIED_FILES = "):
            return ast.literal_eval(ast.parse(src).body[0].value)
    raise SystemExit("no CARRIED_FILES cell")


def materialise(files: dict, root: Path) -> None:
    for name, text in files.items():
        p = root / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8", newline="\n")


def import_workshop(root: Path):
    sys.path.insert(0, str(root))
    for mod in [m for m in sys.modules if m == "workshop" or m.startswith("clipseg_reference")]:
        del sys.modules[mod]
    import workshop  # noqa: PLC0415

    return workshop


def _synthetic_image(seed: int, size=(48, 40)) -> Image.Image:
    rng = np.random.default_rng(seed)
    return Image.fromarray(rng.integers(0, 255, (size[1], size[0], 3), dtype=np.uint8))


def write_byod(directory: Path, n: int = 13, mutate=None) -> Path:
    roles = ["train"] * 8 + ["validation"] * 2 + ["test"] * 2 + ["activity"] * 1 + ["train"] * max(0, n - 13)
    records = []
    (directory / "images").mkdir(parents=True, exist_ok=True)
    (directory / "masks").mkdir(parents=True, exist_ok=True)
    for i in range(n):
        image = _synthetic_image(i)
        image.save(directory / f"images/{i:02d}.png")
        mask = np.zeros((40, 48), dtype=np.uint8)
        mask[5 + i % 5 : 25, 6:30 + i % 7] = 255
        Image.fromarray(mask).save(directory / f"masks/{i:02d}.png")
        records.append({"id": f"r{i:02d}", "image": f"images/{i:02d}.png", "mask": f"masks/{i:02d}.png",
                        "prompt": "square", "role": roles[i], "group_id": f"g{i:02d}"})
    if mutate is not None:
        mutate(directory, records)
    (directory / "manifest.json").write_text(json.dumps({"records": records}), encoding="utf-8")
    return directory


def byod_error(workshop, tmp: Path, mutate) -> str:
    byod = write_byod(tmp / "byod", mutate=mutate)
    root = tmp / "root"
    root.mkdir()
    try:
        workshop.prepare(root, byod)
    except Exception as exc:  # noqa: BLE001
        return f"{type(exc).__name__}: {exc}"
    return "accepted"


class StandInSam2:
    """Returns three candidate masks: a fixed square, the full image and nothing, with quality favouring the square."""

    @classmethod
    def from_pretrained(cls, **_kwargs):
        return cls()

    def segment(self, image, multimask=True, **_kwargs):
        w, h = image.size
        square = np.zeros((h, w), dtype=bool)
        square[h // 4 : 3 * h // 4, w // 4 : 3 * w // 4] = True
        return {"masks": [square, np.ones((h, w), bool), np.zeros((h, w), bool)], "iou_scores": [0.9, 0.5, 0.1]}


def run_sam2_stage_with_stand_in(workshop, root: Path) -> None:
    fake = types.ModuleType("sam2_reference")
    fake.SAM2SegmentationPipeline = StandInSam2
    sys.modules["sam2_reference"] = fake
    import torch  # noqa: PLC0415

    workshop.device = lambda: "cpu"
    workshop.timed = lambda call: (call(), 0.0)
    torch.cuda.max_memory_allocated = lambda *a, **k: 0
    torch.cuda.get_device_name = lambda *a, **k: "stand-in"
    workshop.sam_stage(root, "sam2")


def probe_p01(workshop, nb_cells: dict, prepared: Path | None) -> dict:
    out = {"id": "P01", "finding": "SEG-M1", "basis": "direct execution (real pinned FoodSeg103 boxes, stand-in SAM 2)"}
    if prepared is None:
        out.update(open=None, detail="not run: --prepared not given")
        return out
    pm = {r["id"]: r for r in json.loads((prepared / "outputs/prompt_manifest.json").read_text())["records"]}
    recs = json.loads((prepared / "data/records.json").read_text())["records"]
    activity = [r for r in recs if r["role"] == "activity"]
    stats = {}
    for f in (0.1, 0.25):
        clipped = whole = 0
        for r in activity:
            w, h = Image.open(prepared / r["image"]).size
            b = pm[r["id"]]["box"]
            e = workshop.expand_box(b, (w, h), f)
            ideal = [b[0] - f * (b[2] - b[0]), b[1] - f * (b[3] - b[1]), b[2] + f * (b[2] - b[0]), b[3] + f * (b[3] - b[1])]
            clipped += any(abs(a - i) > 1e-9 for a, i in zip(e, ideal, strict=True))
            whole += e == [0.0, 0.0, float(w), float(h)]
        stats[str(f)] = {"clipped_records": clipped, "whole_image_boxes": whole, "activity_records": len(activity)}
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        for sub in ("data", "outputs"):
            import shutil  # noqa: PLC0415

            shutil.copytree(prepared / sub, work / sub)
        (work / "outputs/stage_receipts.json").unlink(missing_ok=True)
        with contextlib.redirect_stdout(io.StringIO()):
            run_sam2_stage_with_stand_in(workshop, work)
        deltas = json.loads((work / "outputs/box_experiment.json").read_text())
    entry = deltas[0]
    records = entry.get("records", [])
    recorded = bool(records) and all("clipped_sides" in r for r in records) and "clipped_records" in entry
    displayed = "clipped" in nb_cells.get("code-16", "") or "show_box_experiment" in nb_cells.get("code-16", "")
    helper = nb_cells.get("code-04", "")
    displayed = displayed and ("clipped" in helper or "clipped" in nb_cells.get("code-16", ""))
    out.update(open=not (recorded and displayed), detail={"real_box_clipping": stats,
               "box_experiment_records_clipping": recorded, "cell_16_displays_clipping": displayed})
    return out


def probe_p02(nb_cells: dict) -> dict:
    src = nb_cells.get("code-20", "")
    shows = "summary.md" in src and ("show_score_table" in src)
    return {"id": "P02", "finding": "SEG-M2", "basis": "source inspection (cell code-20)", "open": not shows,
            "detail": {"renders_summary_md": "summary.md" in src, "shows_score_table": "show_score_table" in src,
                       "only_file_link": "FileLink" in src and not shows}}


def probe_p03(workshop) -> dict:
    cases = {}
    with tempfile.TemporaryDirectory() as td:
        def bad_mask_size(d, recs):
            Image.fromarray(np.full((20, 20), 255, np.uint8)).save(d / "masks/05.png")

        cases["mask_size_mismatch_at_index_5"] = byod_error(workshop, Path(td) / "a", bad_mask_size)
    with tempfile.TemporaryDirectory() as td:
        def missing_prompt(d, recs):
            del recs[7]["prompt"]

        cases["missing_prompt_at_index_7"] = byod_error(workshop, Path(td) / "b", missing_prompt)
    with tempfile.TemporaryDirectory() as td:
        def missing_mask_key(d, recs):
            del recs[4]["mask"]

        cases["missing_mask_key_at_index_4"] = byod_error(workshop, Path(td) / "c", missing_mask_key)
    with tempfile.TemporaryDirectory() as td:
        def tiny_image(d, recs):
            Image.fromarray(np.zeros((8, 8, 3), np.uint8)).save(d / "images/03.png")

        cases["image_side_8px_at_index_3"] = byod_error(workshop, Path(td) / "d", tiny_image)
    with tempfile.TemporaryDirectory() as td:
        cases["valid_13_records"] = byod_error(workshop, Path(td) / "e", None)
    expected = {"mask_size_mismatch_at_index_5": "r05", "missing_prompt_at_index_7": "r07",
                "missing_mask_key_at_index_4": "r04", "image_side_8px_at_index_3": "r03"}
    named = {k: (v != "accepted" and expected[k] in v and "records[0]" not in v) for k, v in cases.items() if k in expected}
    return {"id": "P03", "finding": "SEG-m1", "basis": "direct execution (synthetic BYOD directory, carried runner prepare)",
            "open": not all(named.values()), "detail": {"messages": cases, "names_offending_record": named}}


def probe_p04(nb_cells: dict) -> dict:
    s6 = nb_cells.get("code-14", "")
    helper = nb_cells.get("code-04", "")
    has_baseline = "baselines.json" in s6
    has_pr = "Precision" in helper and "Recall" in helper
    return {"id": "P04", "finding": "SEG-m2", "basis": "source inspection (cells code-04, code-14, md-09, md-15)",
            "open": not (has_baseline and has_pr), "detail": {"section6_table_includes_filled_box": has_baseline,
                                                              "score_table_has_precision_recall": has_pr}}


def probe_p05(workshop_src: str) -> dict:
    body = workshop_src[workshop_src.index("def report("):workshop_src.index("def begin_stage(")]
    md_part = body[body.index("markdown = ["):body.index("summary.md")]
    want = {"reload": "Fresh reload" in md_part, "paired": "improved" in md_part,
            "activity": "box" in md_part.lower() and "expan" in md_part.lower()}
    return {"id": "P05", "finding": "SEG-m3", "basis": "source inspection (carried workshop.py report())",
            "open": not all(want.values()), "detail": want}


def probe_p06(nb_cells: dict) -> dict:
    helper = nb_cells.get("code-04", "")
    reprint_on_success = bool(re.search(r"result\.wait\(\)\n    print\(log\.read_text", helper))
    reload_full = "show_json('outputs/reload_parity.json')" in nb_cells.get("code-12", "")
    history_full = "show_json('outputs/training_history.json')" in nb_cells.get("code-10", "")
    return {"id": "P06", "finding": "SEG-m4", "basis": "source inspection (cells code-04, code-10, code-12)",
            "open": reprint_on_success or reload_full or history_full,
            "detail": {"log_tail_reprinted_after_success": reprint_on_success,
                       "reload_parity_prints_every_record": reload_full,
                       "training_history_printed_raw": history_full}}


def probe_p07(nb_cells: dict) -> dict:
    src = nb_cells.get("code-04", "")
    return {"id": "P07", "finding": "SEG-m5", "basis": "source inspection (cell code-04)",
            "open": "transformers.__version__" not in src, "detail": {"prints_transformers_version": "transformers.__version__" in src}}


def probe_p08(nb_cells: dict, nb: dict) -> dict:
    titled = {cid: nb_cells[cid].lstrip().startswith("# @title Infrastructure") for cid in ("code-02", "code-04")}
    how_to = "How to use this notebook" in nb_cells.get("md-00", "")
    return {"id": "P08", "finding": "SEG-m6", "basis": "source inspection (cells md-00, code-02, code-04)",
            "open": not (all(titled.values()) and how_to), "detail": {"infrastructure_titles": titled, "how_to_use": how_to}}


def probe_p09(nb_cells: dict) -> dict:
    text = "\n".join(v for k, v in nb_cells.items() if k.startswith("md-"))
    has = "Glossary" in text
    return {"id": "P09", "finding": "SEG-m7", "basis": "source inspection (all markdown cells)", "open": not has,
            "detail": {"glossary_present": has}}


def probe_p10(nb_cells: dict) -> dict:
    src = nb_cells.get("code-18", "")
    instructs = "Files" in src or "Files" in nb_cells.get("md-17", "")
    return {"id": "P10", "finding": "SEG-m8", "basis": "source inspection (cell code-18); Colab link behaviour not verified",
            "open": not instructs, "detail": {"only_filelink_absolute_path": "FileLink(str(ROOT" in src and not instructs}}


def probe_p11(nb_cells: dict) -> dict:
    md = nb_cells.get("md-00", "")
    stale = "still need fresh-Colab measurement" in md
    return {"id": "P11", "finding": "SEG-m9", "basis": "source inspection (md-00) vs docs/release-verification.md",
            "open": stale or "393" not in md, "detail": {"says_unmeasured": stale, "states_measured_time": "393" in md}}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("notebook", type=Path)
    ap.add_argument("--prepared", type=Path)
    ap.add_argument("--out", type=Path, default=Path("results.json"))
    args = ap.parse_args()
    nb = load_notebook(args.notebook)
    cells = cells_by_id(nb)
    files = carried_files(nb)
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        materialise(files, root)
        workshop = import_workshop(root)
        results = [
            probe_p01(workshop, cells, args.prepared),
            probe_p02(cells),
            probe_p03(workshop),
            probe_p04(cells),
            probe_p05(files["workshop.py"]),
            probe_p06(cells),
            probe_p07(cells),
            probe_p08(cells, nb),
            probe_p09(cells),
            probe_p10(cells),
            probe_p11(cells),
        ]
    payload = {
        "notebook": str(args.notebook.name),
        "notebook_sha256": hashlib.sha256(args.notebook.read_bytes()).hexdigest(),
        "workshop_py_sha256": hashlib.sha256(files["workshop.py"].encode()).hexdigest(),
        "environment": f"CPU only, Python {sys.version.split()[0]}; no model weights loaded",
        "probes": results,
    }
    args.out.write_text(json.dumps(payload, indent=2, default=str) + "\n", encoding="utf-8")
    for r in results:
        print(r["id"], r["finding"], "OPEN" if r["open"] else ("not run" if r["open"] is None else "clear"))


if __name__ == "__main__":
    main()
