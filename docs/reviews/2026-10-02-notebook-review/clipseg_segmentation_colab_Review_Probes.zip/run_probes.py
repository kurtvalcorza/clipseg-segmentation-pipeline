"""Probes for the Notebook Review Framework v1 review of tutorials/clipseg_segmentation_colab.ipynb (CLS-*).

Environment used by the review: Windows, CPU only (CUDA_VISIBLE_DEVICES=-1), the build venv
`C:/Users/Kurt Valcorza/venvs/dimer-next16` (Python 3.12.10, torch 2.14.0+cu130, transformers 4.57.6,
numpy 2.5.3, pillow 11.3.0, pyarrow 25.0.1 -- the notebook's pins), nothing installed.

Every notebook code cell is executed VERBATIM from the notebook JSON in one namespace, except:
  * cell 3 runs with DIMER_NOTEBOOK_CI_PREINSTALLED=1 (the notebook's own executor hook; install skipped);
  * EPOCHS is substituted 8 -> 1 (form-field literal, the way an EXE6 executor sets a field) to keep the probe
    inside the review's 20-minute CPU cap.  The default-path numbers below are therefore NOT the 8-epoch run;
  * the pinned snapshot files and the 8 FoodSeg103 row-group files are hard-linked into a scratch working
    directory (re-hashed by the notebook's own verify_snapshot / fetch_corpus), so this is NOT a clean runtime;
  * the BYOD branch is driven by a google.colab.files.upload shim returning one generated zip (EXE2: the
    notebook has no location field).

Usage:  python run_probes.py <repo_worktree> <source_clone_with_weights> <workdir>
        python run_probes.py <repo_worktree> <source_clone> <workdir> --layout-only   (loader probe only; no model)
Writes results.json and source_manifest.json next to this script.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import sys
import time
import types
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path(sys.argv[1])
SRC_CLONE = Path(sys.argv[2])
WORK = Path(sys.argv[3])
NB_PATH = REPO / "tutorials" / "clipseg_segmentation_colab.ipynb"
RESULTS: dict = {"environment": {}, "static": {}, "default": {}, "state": {}, "byod_loader": {}, "byod_e2e": {}}
T_START = time.perf_counter()
LAYOUT_ONLY = "--layout-only" in sys.argv


def save():
    (HERE / "results.json").write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


if LAYOUT_ONLY:
    pass  # see layout_probe() at the end of the file
# ---------------------------------------------------------------- source manifest
inspected = [
    "tutorials/clipseg_segmentation_colab.ipynb", "tutorials/README.md", "README.md", "STATUS.md", "MODEL_CARD.md",
    "docs/release-verification.md", "docs/WEIGHTS.md", "tools/build_notebook.py", "tools/notebook_template.py",
    "tools/validate_release_assets.py", "src/clipseg_segmentation_pipeline/pipeline.py",
    "src/clipseg_segmentation_pipeline/metrics.py", "src/clipseg_segmentation_pipeline/samples.py", "pyproject.toml",
]
evidence_dir = Path("C:/Users/Kurt Valcorza/Projects/.agent/backups/kaggle-e2e-2026-09-19/out/dimer-nb2-clipseg-segmentation/v3/evidence")
manifest = {rel: sha(REPO / rel) for rel in inspected}
for name in ("run_summary.json", "executed.ipynb", "executed-pass1.ipynb"):
    manifest["workspace:.agent/backups/kaggle-e2e-2026-09-19/.../v3/evidence/" + name] = sha(evidence_dir / name)
(HERE / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

if LAYOUT_ONLY:
    exec(compile(open(__file__, encoding="utf-8").read().split("# ---------------------------------------------------------------- appended probe")[-1].split(chr(10), 1)[1], __file__, "exec"))
    layout_probe()
    sys.exit(0)
nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
md = {i: "".join(c["source"]) for i, c in enumerate(cells) if c["cell_type"] == "markdown"}
code = {i: "".join(c["source"]) for i, c in enumerate(cells) if c["cell_type"] == "code"}

# ---------------------------------------------------------------- static probes
st = RESULTS["static"]
st["cells"] = {"total": len(cells), "code": len(code), "markdown": len(md)}
st["carried_module_lines"] = {i: code[i].count("\n") + 1 for i in (5, 7, 9)}
st["form_fields"] = sorted(set(re.findall(r"^(\w+)\s*=.*#\s*@param", "\n".join(code.values()), re.M)))
st["THRESHOLD_is_form_field"] = "THRESHOLD" in st["form_fields"]
st["THRESHOLD_assignment"] = [l for l in code[15].splitlines() if l.startswith("THRESHOLD")]
st["byod_location_field"] = any("BYOD_PATH" in s or "BYOD_DIR" in s for s in code.values())
st["byod_branch_imports_google_colab"] = "from google.colab import files" in code[13]
st["panel_prose_says_frozen_panel"] = "the frozen mask and the adapted mask side by side" in md[22]
st["panel_code_panels"] = re.findall(r"'panels': \[([^\]]*)\]", code[23])
st["scene_miou_claims"] = {
    "cell14_inference_only_card": re.findall(r"recorded a mean IoU of ([0-9.]+) on the four drawn shapes", md[14]),
    "cell22_and_24_build_record": re.findall(r"\(mean IoU ([0-9.]+)\)", md[22] + md[24]),
    "cell24_interpretation": re.findall(r"\(([0-9.]+) → ([0-9.]+) mean IoU", md[24]),
}
st["timing_claims"] = {
    "cell0": re.findall(r"On a Tesla T4 the default path took ([^(]+)\(", md[0]),
    "cell1": re.findall(r"(about \d+ minutes of cell time for the whole path[^.]*)", md[1]),
}
st["byod_minimum_claim"] = re.findall(r"at least (\w+) images", md[0])
st["guided_layer_markers"] = {k: any(k.lower() in s.lower() for s in md.values()) for k in (
    "How to use this notebook", "Roadmap", "Glossary", "Predict", "Checkpoint", "What to notice", "Expected result",
    "Infrastructure", "Conclusion template", "Who this notebook is for", "Look for")}
st["look_for_count"] = sum(s.count("Look for") + s.count("Watch the") for s in md.values())
st["optional_experiments_rerun_instructions"] = re.findall(r"\*\*Optional experiments[^\n]*", md[24])
st["adapt_resets_to_base_decoder"] = "load_state_dict" in code[7][code[7].find("def adapt("):code[7].find("def save_artifact(")]
st["declared_spec"] = nb["metadata"]["dimer"]["notebook_spec"]
rs = json.loads((evidence_dir / "run_summary.json").read_text(encoding="utf-8"))
st["kaggle_record"] = {
    "committed_blob": rs["identity"]["committed_blob"], "fetched_blob_verified": rs["identity"]["fetched_blob_verified"],
    "image_versions_before_run": {k: rs["identity"]["image_versions_before_run"][k] for k in ("torch", "numpy", "transformers")},
    "passes": [{k: v for k, v in p.items() if k != "error"} for p in rs["runner"]["passes"]],
    "pass1_error_tail": rs["runner"]["passes"][0].get("error", "")[-400:],
    "restarted_after_install_cell": rs["runner"].get("restarted_after_install_cell"),
    "wall_s": rs["runner"].get("wall_s"),
}
# Kaggle executed notebook: per-record IoU counts quoted by the prose (records <0.2 / >0.8, zero-IoU phrases)
ev_report = evidence_dir / "outputs" / "clipseg_segmentation_evaluation_report.json"
if ev_report.exists():
    rep = json.loads(ev_report.read_text(encoding="utf-8"))
    rows = rep["per_record"]
    st["kaggle_per_record"] = {
        "n": len(rows),
        "frozen_lt_0.2": sum(r["iou"] < 0.2 for r in rows), "frozen_gt_0.8": sum(r["iou"] > 0.8 for r in rows),
        "adapted_lt_0.2": sum(r["adapted_iou"] < 0.2 for r in rows), "adapted_gt_0.8": sum(r["adapted_iou"] > 0.8 for r in rows),
        "frozen_zero_prompts": sorted({r["prompt"] for r in rows if r["iou"] == 0.0}),
        "adapted_zero_prompts": sorted({r["prompt"] for r in rows if r["adapted_iou"] == 0.0}),
    }
else:
    st["kaggle_per_record"] = f"missing {ev_report}"
save()

# ---------------------------------------------------------------- set up the working directory (not clean)
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
wdir = WORK / "weights" / "clipseg-rd64-refined"
wdir.mkdir(parents=True, exist_ok=True)
for f in (SRC_CLONE / "weights" / "clipseg-rd64-refined").iterdir():
    if f.name == "dimer-base-manifest.json":
        continue  # the notebook writes this file; never hard-link it
    target = wdir / f.name
    if not target.exists():
        os.link(f, target)
cdir = WORK / "weights" / "foodseg103"
cdir.mkdir(parents=True, exist_ok=True)
for f in (SRC_CLONE / "weights" / "foodseg103").glob("validation-rg*.parquet"):
    if not (cdir / f.name).exists():
        os.link(f, cdir / f.name)

os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["HF_HUB_OFFLINE"] = "1"

NS: dict = {"__name__": "__main__"}
TIMES: dict = {}


def run(i: int, src: str | None = None, label: str | None = None):
    text = code[i] if src is None else src
    t = time.perf_counter()
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        exec(compile(text, f"<cell {i}>", "exec"), NS)
        err = None
    except BaseException as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    finally:
        sys.stdout = old
    TIMES[label or str(i)] = round(time.perf_counter() - t, 1)
    out = buf.getvalue()
    print(f"[cell {i} {label or ''}] {TIMES[label or str(i)]}s err={err}\n{out[-1500:]}", flush=True)
    return out, err


env = RESULTS["environment"]
import importlib.metadata as m  # noqa: E402

env.update({"python": sys.version.split()[0], **{d: m.version(d) for d in ("torch", "transformers", "numpy", "pillow", "pyarrow")},
            "device": "cpu (CUDA_VISIBLE_DEVICES=-1)", "epochs_substituted": "EPOCHS 8 -> 1", "install": "skipped (DIMER_NOTEBOOK_CI_PREINSTALLED=1)",
            "weights": "hard-linked pinned files, re-hashed by verify_snapshot", "row_groups": "hard-linked cache, re-hashed by fetch_corpus"})

# ---------------------------------------------------------------- default path (EPOCHS=1 stand-in)
d = RESULTS["default"]
order = sorted(code)
for i in order:
    src = code[i]
    if i == 19:
        src = src.replace("EPOCHS = 8  # @param", "EPOCHS = 1  # @param")
    out, err = run(i, src)
    d[f"cell{i}"] = {"seconds": TIMES[str(i)], "error": err, "tail": out[-600:]}
    save()
    if err:
        break
if not any(v.get("error") for v in d.values() if isinstance(v, dict)):
    d["summary"] = {
        "frozen_test": {k: round(NS["frozen_test"][k], 4) for k in ("miou", "dice", "pixel_precision", "pixel_recall")},
        "adapted_test": {k: round(NS["adapted_test"][k], 4) for k in ("miou", "dice", "pixel_precision", "pixel_recall")},
        "history_epoch0_val_miou": NS["adapt_result"]["history"][0]["val"]["miou"],
        "scene_frozen_miou": NS["frozen_scene_report"]["metrics"][-1]["value"] if NS["frozen_scene_report"]["metrics"] else None,
        "scene_adapted_miou": NS["adapted_scene_report"]["metrics"][-1]["value"] if NS["adapted_scene_report"]["metrics"] else None,
        "parity": NS["parity"], "outputs": sorted(os.listdir("outputs")),
        "example_panel_size": list(__import__("PIL.Image", fromlist=["Image"]).open(next(Path("outputs/clipseg_segmentation_examples").iterdir())).size),
    }
save()

# ---------------------------------------------------------------- state probes (rerun instructions)
s = RESULTS["state"]
if "summary" in d:
    adapted_miou = NS["adapted_test"]["miou"]
    # Optional experiment "set THRESHOLD to 0.3 or 0.7 before Section 6 ... for both the frozen and the adapted model":
    # the learner re-runs Section 6 (cell 17) after the default run.
    run(17, "THRESHOLD = 0.5\n" + code[17], label="rerun17")
    s["rerun_section6_after_default"] = {
        "frozen_test_miou_reported": round(NS["frozen_test"]["miou"], 4),
        "adapted_test_miou_from_default_run": round(adapted_miou, 4),
        "frozen_test_flag_adapted": NS["frozen_test"]["adapted"],
        "printed_label": "frozen_model_test",
        "seconds": TIMES["rerun17"],
    }
    save()
    # Optional experiment "raise EPOCHS and watch the validation mean IoU pick the epoch": re-run cell 19.
    if time.perf_counter() - T_START < 900:
        out, err = run(19, code[19].replace("EPOCHS = 8  # @param", "EPOCHS = 1  # @param"), label="rerun19")
        h0 = NS["adapt_result"]["history"][0]
        s["rerun_section7_after_default"] = {
            "epoch0_note": h0.get("note"), "epoch0_val_miou": h0["val"]["miou"],
            "first_run_epoch0_val_miou": d["summary"]["history_epoch0_val_miou"], "error": err, "seconds": TIMES["rerun19"],
        }
    else:
        s["rerun_section7_after_default"] = "skipped: time cap"
    save()

# ---------------------------------------------------------------- BYOD loader cases (no model)
from PIL import Image, ImageDraw  # noqa: E402

import numpy as np  # noqa: E402

COLOURS = {"a red circle": (220, 40, 40), "a blue square": (40, 70, 200), "a yellow triangle": (250, 200, 30)}


def make_record(k: int, size=(256, 192)):
    phrase = list(COLOURS)[k % 3]
    rng = np.random.default_rng(k)
    bg = tuple(int(x) for x in rng.integers(150, 250, 3))
    img = Image.new("RGB", size, bg)
    msk = Image.new("L", size, 0)
    x0, y0 = int(rng.integers(10, 90)), int(rng.integers(10, 70))
    w = int(rng.integers(60, 110))
    box = [x0, y0, x0 + w, y0 + w]
    for draw, fill in ((ImageDraw.Draw(img), COLOURS[phrase]), (ImageDraw.Draw(msk), 255)):
        if "circle" in phrase:
            draw.ellipse(box, fill=fill)
        elif "square" in phrase:
            draw.rectangle(box, fill=fill)
        else:
            draw.polygon([(x0, y0 + w), (x0 + w // 2, y0), (x0 + w, y0 + w)], fill=fill)
    return phrase, img, msk


def png(im) -> bytes:
    b = io.BytesIO()
    im.save(b, format="PNG")
    return b.getvalue()


def jpg(im) -> bytes:
    b = io.BytesIO()
    im.convert("RGB").save(b, format="JPEG", quality=75)
    return b.getvalue()


def make_zip(path: Path, n: int, *, extra=None, mask_fmt="png", csv_override=None, prefix=""):
    rows = ["file,mask,prompt"]
    with zipfile.ZipFile(path, "w") as z:
        for k in range(n):
            phrase, img, msk = make_record(k)
            z.writestr(f"{prefix}img{k:03d}.png", png(img))
            mname = f"{prefix}img{k:03d}_mask.{mask_fmt}"
            z.writestr(mname, png(msk) if mask_fmt == "png" else jpg(msk))
            rows.append(f"img{k:03d}.png,img{k:03d}_mask.{mask_fmt},{phrase}")
        z.writestr("masks.csv", csv_override if csv_override is not None else "\n".join(rows) + "\n")
        for name, data in (extra or {}).items():
            z.writestr(name, data)
    return path


L = RESULTS["byod_loader"]
load_byod_dataset, split_dataset, validate_dataset = NS["load_byod_dataset"], NS["split_dataset"], NS["validate_dataset"]


def cell13_path(zpath: Path):
    """What cell 13's BYOD branch does after the upload: load, split, validate each split, disjoint check."""
    recs = load_byod_dataset(zpath)
    sp = split_dataset(recs, seed=42)
    sizes = {k: len(v) for k, v in sp.items()}
    try:
        for name, part in sp.items():
            validate_dataset(part)
    except ValueError as exc:
        return {"loaded": len(recs), "split": sizes, "verdict": "rejected in cell 13", "message": str(exc)}
    return {"loaded": len(recs), "split": sizes, "verdict": "accepted"}


bdir = WORK / "byod"
bdir.mkdir(exist_ok=True)
cases = {}
for n in (8, 20, 37, 38, 49, 50, 60):
    cases[f"{n} images"] = lambda n=n: cell13_path(make_zip(bdir / f"n{n}.zip", n))
cases["macOS zip (__MACOSX/._img000.png + .DS_Store)"] = lambda: cell13_path(make_zip(bdir / "mac.zip", 60, extra={"__MACOSX/._img000.png": b"\x00\x05\x16\x07", ".DS_Store": b"\x00"}))
cases["two folders, same basename (a/img000.png also in b/)"] = lambda: (lambda z: {"result": cell13_path(z), "note": "second member silently replaces the first if accepted"})(
    make_zip(bdir / "dup.zip", 60, extra={"other/img000.png": png(Image.new("RGB", (256, 192), (0, 0, 0)))}))
cases["JPEG masks"] = lambda: (lambda z: (lambda recs: {"loaded": len(recs), "mean_area_png_vs_jpeg": None})(load_byod_dataset(z)))(make_zip(bdir / "jpg.zip", 60, mask_fmt="jpg"))
cases["masks.csv missing"] = lambda: cell13_path(make_zip(bdir / "nocsv.zip", 8, csv_override=None) if False else (lambda p: (zipfile.ZipFile(p, "w").close(), p)[1])(bdir / "empty.zip"))
cases["masks.csv column 'label' instead of 'prompt'"] = lambda: cell13_path(make_zip(bdir / "col.zip", 60, csv_override="file,mask,label\nimg000.png,img000_mask.png,a red circle\n"))
cases["mask of the wrong size"] = None
cases["prompt of 80 characters"] = lambda: cell13_path(make_zip(bdir / "long.zip", 60, csv_override="file,mask,prompt\n" + "".join(f"img{k:03d}.png,img{k:03d}_mask.png,{'x' * 80}\n" for k in range(60))))
cases["a .txt file in the zip"] = lambda: cell13_path(make_zip(bdir / "txt.zip", 60, extra={"README.txt": b"my data"}))
cases["not a zip (a .tar renamed)"] = lambda: cell13_path((lambda p: (p.write_bytes(b"not a zip"), p)[1])(bdir / "bad.zip"))


def wrong_size():
    p = bdir / "size.zip"
    make_zip(p, 60)
    with zipfile.ZipFile(p, "a") as z:
        pass
    # rebuild with one mask of a different size
    rows = ["file,mask,prompt"]
    with zipfile.ZipFile(p, "w") as z:
        for k in range(60):
            phrase, img, msk = make_record(k)
            if k == 3:
                msk = msk.resize((128, 96))
            z.writestr(f"img{k:03d}.png", png(img))
            z.writestr(f"img{k:03d}_mask.png", png(msk))
            rows.append(f"img{k:03d}.png,img{k:03d}_mask.png,{phrase}")
        z.writestr("masks.csv", "\n".join(rows) + "\n")
    return cell13_path(p)


cases["mask of the wrong size"] = wrong_size
for name, fn in cases.items():
    try:
        L[name] = fn()
    except Exception as exc:  # noqa: BLE001
        L[name] = {"verdict": "rejected", "error": f"{type(exc).__name__}: {exc}"[:300]}
# JPEG mask area inflation, measured directly
recs_png = load_byod_dataset(bdir / "n60.zip")
recs_jpg = load_byod_dataset(bdir / "jpg.zip")
area = lambda recs: float(np.mean([(np.asarray(r["mask"].convert("L")) > 0).mean() for r in recs]))  # noqa: E731
L["JPEG masks"]["mean_area_png_vs_jpeg"] = [round(area(recs_png), 4), round(area(recs_jpg), 4)]
# basename collision: which pixels did img000 end up with?
try:
    recs_dup = load_byod_dataset(bdir / "dup.zip")
    first = next(r for r in recs_dup if r["id"] == "img000")
    L["two folders, same basename (a/img000.png also in b/)"]["img000_mean_pixel"] = float(np.asarray(first["image"]).mean())
    L["two folders, same basename (a/img000.png also in b/)"]["original_img000_mean_pixel"] = float(np.asarray(make_record(0)[1]).mean())
except Exception as exc:  # noqa: BLE001
    L["two folders, same basename (a/img000.png also in b/)"]["load_error"] = str(exc)
save()

# ---------------------------------------------------------------- BYOD end to end through the notebook's cells, after the default run
b = RESULTS["byod_e2e"]
if "summary" in d and time.perf_counter() - T_START < 1000:
    payload = (bdir / "n60.zip").read_bytes()
    colab = types.ModuleType("google.colab")
    colab.files = types.SimpleNamespace(upload=lambda: {"my_shapes.zip": payload})
    google = types.ModuleType("google")
    google.colab = colab
    sys.modules["google"], sys.modules["google.colab"] = google, colab
    prev_scene_adapted = d["summary"]["scene_adapted_miou"]
    ok = True
    for i in [13, 15, 17, 19, 21, 23]:
        src = code[i]
        if i == 13:
            src = src.replace("USE_BYOD = False  # @param", "USE_BYOD = True  # @param")
        if i == 19:
            src = src.replace("EPOCHS = 8  # @param", "EPOCHS = 1  # @param")
        out, err = run(i, src, label=f"byod{i}")
        b[f"cell{i}"] = {"seconds": TIMES[f"byod{i}"], "error": err, "tail": out[-500:]}
        save()
        if err:
            ok = False
            break
    if ok:
        b["labelled_frozen_scene_miou"] = NS["frozen_scene_report"]["metrics"][-1]["value"]
        b["default_run_adapted_scene_miou"] = prev_scene_adapted
        b["labelled_frozen_test_miou"] = round(NS["frozen_test"]["miou"], 4)
        b["labelled_frozen_test_flag_adapted"] = NS["frozen_test"]["adapted"]
        b["epoch0_note_and_val_miou"] = [NS["adapt_result"]["history"][0].get("note"), NS["adapt_result"]["history"][0]["val"]["miou"]]
        # the genuinely frozen model on the same BYOD test records, from a freshly loaded pipeline
        fresh = NS["ClipSegSegmentationPipeline"].from_pretrained(weights_dir=NS["WEIGHTS_DIR"])
        truly_frozen = fresh.evaluate(NS["test_records"], threshold=0.5)
        fresh_val = fresh.evaluate(NS["val_records"], threshold=0.5)
        b["truly_frozen_test_miou"] = round(truly_frozen["miou"], 4)
        b["truly_frozen_val_miou"] = round(fresh_val["miou"], 4)
        b["result_json_data_source"] = json.loads(Path("outputs/clipseg_segmentation_result.json").read_text(encoding="utf-8"))["data_source"]
        b["result_json_corpus_name"] = json.loads(Path("outputs/clipseg_segmentation_result.json").read_text(encoding="utf-8"))["corpus"]["name"]
        b["train_csv_rows"] = sum(1 for _ in open("outputs/clipseg_segmentation_train.csv", encoding="utf-8")) - 1
else:
    b["skipped"] = "default path did not complete or time cap reached"
RESULTS["times"] = TIMES
RESULTS["total_seconds"] = round(time.perf_counter() - T_START, 1)
save()
print("DONE", RESULTS["total_seconds"])


# ---------------------------------------------------------------- appended probe (run separately with --layout-only)
def layout_probe():
    """images/0001.png + masks/0001.png: the common two-folder layout with matching basenames."""
    sys.path.insert(0, str(REPO / "src"))
    from clipseg_segmentation_pipeline.samples import load_byod_dataset as lb, split_dataset as sd, validate_dataset as vd
    from PIL import Image, ImageDraw
    import numpy as np
    zp = WORK / "byod" / "two_folders.zip"
    zp.parent.mkdir(parents=True, exist_ok=True)
    rows = ["file,mask,prompt"]
    with zipfile.ZipFile(zp, "w") as z:
        for k in range(60):
            img = Image.new("RGB", (256, 192), (200, 180, 160)); ImageDraw.Draw(img).ellipse([20 + k, 30, 120 + k, 130], fill=(220, 40, 40))
            msk = Image.new("L", (256, 192), 0); ImageDraw.Draw(msk).ellipse([20 + k, 30, 120 + k, 130], fill=255)
            for name, im in ((f"images/{k:04d}.png", img), (f"masks/{k:04d}.png", msk)):
                b = io.BytesIO(); im.save(b, format="PNG"); z.writestr(name, b.getvalue())
            rows.append(f"images/{k:04d}.png,masks/{k:04d}.png,a red circle")
        z.writestr("masks.csv", "\n".join(rows) + "\n")
    recs = lb(zp)
    sp = sd(recs, seed=42)
    for part in sp.values():
        vd(part)
    r0 = recs[0]
    arr = np.asarray(r0["image"])
    out = {"verdict": "accepted", "records": len(recs), "image_unique_colours": int(len(np.unique(arr.reshape(-1, 3), axis=0))),
           "image_equals_mask_rgb": bool(np.array_equal(arr, np.asarray(Image.open(io.BytesIO(zipfile.ZipFile(zp).read("masks/0000.png"))).convert("RGB"))))}
    res = json.loads((HERE / "results.json").read_text(encoding="utf-8"))
    res["byod_loader"]["images/ + masks/ folders with matching basenames"] = out
    (HERE / "results.json").write_text(json.dumps(res, indent=2, default=str), encoding="utf-8")
    print(out)
